12 SVG icons. Set CSS color to recolor; use any width/height. Each icon has a 24 × 24 viewBox.
