Open pixelpress.html in a modern desktop browser. No installation or network needed. Width is capped at the original image size. JPEG quality controls compression; PNG is lossless.
