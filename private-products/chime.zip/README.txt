Four original synthesized sounds. Mono PCM WAV, 44.1 kHz, 16 bit. Start playback at a comfortable volume.
